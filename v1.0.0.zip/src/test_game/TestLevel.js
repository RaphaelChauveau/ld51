class TestLevel {
    constructor(game) {
        this.game = game;
        this.game._scene.bgColor = "#AAAAAA";
    }

    update = (delta) => {

    }

    draw = (scene) => {

    }
}

export default TestLevel;
